/**
 * WP Test Plugin Scripts
 */

(function( $ ) {
    'use strict';

    $(document).ready(function() {
        // Add custom JavaScript functionality here
        console.log('WP Test Plugin loaded');
    });

})( jQuery );
